//
//  Twitter-Aperto-BridgingHeader.h
//  Twitter Aperto
//
//  Created by Karthik Kumar on 11/05/18.
//  Copyright © 2018 Karthik Kumar. All rights reserved.
//

#ifndef Twitter_Aperto_BridgingHeader_h
#define Twitter_Aperto_BridgingHeader_h

#import <StTwitter/STTwitter.h>

#endif /* Twitter_Aperto_BridgingHeader_h */
