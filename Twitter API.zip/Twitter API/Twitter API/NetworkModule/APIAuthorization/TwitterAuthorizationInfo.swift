//
//  TwitterAuthorizationInfo.swift
//  Twitter API
//
//  Created by Karthik Kumar on 09/05/18.
//  Copyright © 2018 Karthik Kumar. All rights reserved.
//

import Foundation

enum TwitterAuthorizationInfo: String {
    case apiKey = "qQ43bGePqkwjTnY3xNsak81zG"
    case apiSecret = "MqLpdmpHWdheqgEAJXQOwh9G6ksYa2iNnWNEkTmtZcBGGir6UA"
    case accessToken = "uBtrvSEapJ2DXihM1ho4XVHGOYtfBpCFXDvcRxc"
    case accessTokenSecret = "mW849PDnllq7OeTvsjDrDN4gBD78FjedyKu6boz0gFoJb"
    case ownerId = "2184398466"
    case version = "1.1"
}
